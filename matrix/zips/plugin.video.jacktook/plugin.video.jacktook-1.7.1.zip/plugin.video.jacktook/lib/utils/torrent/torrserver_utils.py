import hashlib
from io import BytesIO
import requests
from lib.utils.kodi.kodi_formats import is_picture, is_text, is_video, is_music
from lib.utils.kodi.utils import (
    ADDON_HANDLE,
    JACKTORR_ADDON,
    buffer_and_play,
    build_url,
    kodilog,
    notification,
    refresh,
    show_picture,
    translation,
)
from lib.utils.general.utils import (
    USER_AGENT_HEADER,
    build_list_item,
)
from lib.vendor.bencodepy import bencodepy

from xbmcplugin import addDirectoryItem, endOfDirectory
from xbmcgui import Dialog

from lib.utils.torrent.torrserver_init import get_torrserver_api


def torrent_status(info_hash):
    status = get_torrserver_api().get_torrent_info(link=info_hash)
    notification(
        "{}".format(status.get("stat_string")),
        status.get("name"),
        sound=False,
    )


def torrent_files(params):
    info_hash = params.get("info_hash")

    info = get_torrserver_api().get_torrent_info(link=info_hash)
    file_stats = info.get("file_stats")

    for f in file_stats:
        name = f.get("path")
        id = f.get("id")
        serve_url = get_torrserver_api().get_stream_url(
            link=info_hash, path=f.get("path"), file_id=id
        )
        file_li = build_list_item(name, "download.png")
        file_li.setPath(serve_url)

        context_menu_items = []
        info_type = None
        info_labels = {"title": info.get("title")}
        kwargs = dict(info_hash=info_hash, file_id=id, path=name)

        if is_picture(name):
            url = build_url("display_picture", **kwargs)
            file_li.setInfo("pictures", info_labels)
        elif is_text(name):
            url = build_url("display_text", **kwargs)
        else:
            url = serve_url
            if is_video(name):
                info_type = "video"
            elif is_music(name):
                info_type = "music"

            if info_type is not None:
                file_li.setInfo(info_type, info_labels)
                file_li.setProperty("IsPlayable", "true")

                context_menu_items.append(
                    (
                        translation(30700),
                        buffer_and_play(**kwargs),
                    )
                )

                file_li.addContextMenuItems(context_menu_items)

        if info_type is not None:
            addDirectoryItem(
                ADDON_HANDLE,
                build_url("play_url", url=serve_url, name=name),
                file_li,
            )
        else:
            addDirectoryItem(ADDON_HANDLE, url, file_li)
        endOfDirectory(ADDON_HANDLE)


def torrent_action(params):
    info_hash = params.get("info_hash")
    action_str = params.get("action_str")

    needs_refresh = True

    if action_str == "drop":
        get_torrserver_api().drop_torrent(info_hash)
    elif action_str == "remove_torrent":
        get_torrserver_api().remove_torrent(info_hash)
    elif action_str == "torrent_status":
        torrent_status(info_hash)
        needs_refresh = False
    else:
        kodilog(f"Unknown action: {action_str}")
        needs_refresh = False

    if needs_refresh:
        refresh()


def display_picture(params):
    show_picture(
        get_torrserver_api().get_stream_url(
            link=params.get("info_hash"),
            path=params.get("path"),
            file_id=params.get("file_id"),
        )
    )


def display_text(params):
    r = requests.get(
        get_torrserver_api().get_stream_url(
            link=params.get("info_hash"),
            path=params.get("path"),
            file_id=params.get("file_id"),
        )
    )
    Dialog().textviewer(params.get("path"), r.text)


def add_source_to_torrserver(
    magnet="", url="", info_hash="", title="", poster=""
):
    if not JACKTORR_ADDON:
        notification(translation(30253))
        return None

    api = get_torrserver_api()
    if api is None:
        notification(translation(30253))
        return None

    if not magnet and info_hash:
        magnet = convert_info_hash_to_magnet(info_hash)

    try:
        if magnet:
            added_hash = api.add_magnet(magnet, title=title, poster=poster)
        elif url and url.startswith("http"):
            response = requests.get(url, timeout=15, headers=USER_AGENT_HEADER)
            response.raise_for_status()
            torrent_obj = BytesIO(response.content)
            torrent_obj.name = "torrent.torrent"
            added_hash = api.add_torrent_obj(torrent_obj, title=title, poster=poster)
        else:
            notification(translation(90361))
            return None

        notification(translation(90360))
        return added_hash
    except Exception as exc:
        kodilog(f"Failed to add source to TorrServer: {exc}")
        notification(str(exc))
        return None


def extract_magnet_from_url(url: str):
    try:
        response = requests.get(url, timeout=10, headers=USER_AGENT_HEADER)
        if response.status_code == 200:
            return extract_torrent_metadata(response.content)
        else:
            kodilog(f"Failed to fetch content from URL: {url}")
            return None
    except Exception as e:
        kodilog(f"Failed to fetch content from URL: {url}, Error: {e}")
        return None


def extract_torrent_metadata(content: bytes):
    kodilog("Extracting torrent metadata...")
    try:
        torrent_data = bencodepy.decode(content)
        info = torrent_data[b"info"]
        info_encoded = bencodepy.encode(info)
        info_hash = hashlib.sha1(info_encoded).hexdigest()
        return convert_info_hash_to_magnet(info_hash)
    except Exception as e:
        kodilog(f"Error occurred extracting torrent metadata: {e}")
        return None


def convert_info_hash_to_magnet(info_hash: str) -> str:
    return f"magnet:?xt=urn:btih:{info_hash}"
