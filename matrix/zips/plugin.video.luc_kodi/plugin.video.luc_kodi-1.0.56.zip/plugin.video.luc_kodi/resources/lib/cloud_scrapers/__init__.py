# -*- coding: UTF-8 -*-

import os
from pkgutil import walk_packages
from resources.lib.modules.control import setting as getSetting
debug_enabled = getSetting('debug.enabled') == 'true'

def cloudSources():
	try:
		sourceDict = []
		sourceFolderLocation = os.path.dirname(__file__)
		for loader, module_name, is_pkg in walk_packages([sourceFolderLocation]):
			if is_pkg or 'cloud_utils' in module_name: continue
			if enabledCheck(module_name):
				try:
					# importlib.import_module: compatible Py3.6 -> 3.12+. find_module()/
					# load_module() fueron eliminados en Python 3.12 (Kodi 22+).
					import importlib
					module = importlib.import_module('resources.lib.cloud_scrapers.%s' % module_name)
					sourceDict.append((module_name, module.source))
				except Exception as e:
					if debug_enabled:
						from resources.lib.modules import log_utils
						log_utils.log('Error: Loading cloud scraper module: "%s": %s' % (module_name, e), level=log_utils.LOGWARNING)
		return sourceDict
	except:
		from resources.lib.modules import log_utils
		log_utils.error()
		return []

def enabledCheck(cloud_scraper):
	parent_dict = {'ad_cloud': 'alldebrid', 'pm_cloud': 'premiumize', 'rd_cloud': 'realdebrid', 'tb_cloud': 'torbox'}
	try:
		parent_setting = parent_dict.get(cloud_scraper)
		if not parent_setting: return False
		if not getSetting(parent_setting + '.token'): return False
		if getSetting(parent_setting + '.enable') == 'true' and getSetting(cloud_scraper + '.enabled') == 'true': return True
		else: return False
	except:
		from resources.lib.modules import log_utils
		log_utils.error()
		return False
