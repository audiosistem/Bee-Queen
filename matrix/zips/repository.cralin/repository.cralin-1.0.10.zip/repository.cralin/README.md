# cralin's repository for Kodi

Repository containing cralin's addons for Kodi

## Installation & Updates

* Download the latest released package from [here](https://github.com/cralin/repository.cralin/releases/latest) and upload it to your Kodi installation.
* Go to ADD-ONS -> Install from zip file
* Browse for and select the uploaded zip file.


### Quick download links

Latest released package can be downloaded from [here](https://github.com/cralin/repository.cralin/releases/latest).

