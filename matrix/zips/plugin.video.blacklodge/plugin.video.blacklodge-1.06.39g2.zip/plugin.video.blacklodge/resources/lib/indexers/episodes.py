# -*- coding: utf-8 -*-

from resources.lib.modules import trakt
from resources.lib.modules import bookmarks
from resources.lib.modules import cleangenre
from resources.lib.modules import control
from resources.lib.modules import client
from resources.lib.modules import cache
from resources.lib.modules import playcount
from resources.lib.modules import workers
from resources.lib.modules import views
from resources.lib.modules import utils
from resources.lib.modules import api_keys
from resources.lib.modules import log_utils

import six
from six.moves import urllib_parse

try: from sqlite3 import dbapi2 as database
except: from pysqlite2 import dbapi2 as database

import os,sys,re,datetime,time
import simplejson as json

import requests


params = dict(urllib_parse.parse_qsl(sys.argv[2].replace('?',''))) if len(sys.argv) > 1 else dict()
action = params.get('action')


class seasons:
    def __init__(self):
        self.list = []

        self.session = requests.Session()

        self.showunaired = control.setting('showunaired') or 'true'
        self.specials = control.setting('tv.specials') or 'true'
        self.trailer_source = control.setting('trailer.source') or '2'
        self.datetime = datetime.datetime.utcnow()# - datetime.timedelta(hours = 5)
        self.today_date = self.datetime.strftime('%Y-%m-%d')
        self.lang = control.apiLanguage()['tmdb'] or 'en'

        self.tmdb_user = control.setting('tm.user') or api_keys.tmdb_key
        self.tmdb_show_link = 'https://api.themoviedb.org/3/tv/%s?api_key=%s&language=%s&append_to_response=aggregate_credits,content_ratings,external_ids' % ('%s', self.tmdb_user, '%s')
        self.tmdb_show_lite_link = 'https://api.themoviedb.org/3/tv/%s?api_key=%s&language=en' % ('%s', self.tmdb_user)
        self.tmdb_by_imdb = 'https://api.themoviedb.org/3/find/%s?api_key=%s&external_source=imdb_id' % ('%s', self.tmdb_user)
        self.search_link = 'https://api.themoviedb.org/3/search/tv?api_key=%s&language=en-US&query=%s&page=1' % (self.tmdb_user, '%s')
        self.tmdb_img_link = 'https://image.tmdb.org/t/p/w%s%s'


    def __del__(self):
        self.session.close()


    def get(self, tvshowtitle, year, imdb, tmdb, meta, idx=True, create_directory=True):

        try:
            if idx == True:
                self.list = cache.get(self.tmdb_list, 24, tvshowtitle, year, imdb, tmdb, meta)
                # log_utils.log('idx_list_loaded ')# + repr(self.list))
                if create_directory == True: self.seasonDirectory(self.list)
                return self.list
            else:
                self.list = self.tmdb_list(tvshowtitle, year, imdb, tmdb, lite=True)
                # log_utils.log('nonidx_list_loaded ')# + repr(self.list))
                return self.list
        except:
            log_utils.log('seasons_get', 1)


    def tmdb_list(self, tvshowtitle, year, imdb, tmdb, meta=None, lite=False):
        try:

            if tmdb == '0' and not imdb == '0':
                try:
                    url = self.tmdb_by_imdb % imdb
                    result = self.session.get(url, timeout=10).json()
                    id = result['tv_results'][0]
                    tmdb = id['id']
                    if not tmdb: tmdb = '0'
                    else: tmdb = str(tmdb)
                except:
                    pass

            if tmdb == '0':
                try:
                    url = self.search_link % (urllib_parse.quote(tvshowtitle)) + '&first_air_date_year=' + year
                    result = self.session.get(url, timeout=10).json()
                    results = result['results']
                    show = [r for r in results if cleantitle.get(r.get('name')) == cleantitle.get(tvshowtitle)][0]# and re.findall(r'(\d{4})', r.get('first_air_date'))[0] == year][0]
                    tmdb = show['id']
                    if not tmdb: tmdb = '0'
                    else: tmdb = str(tmdb)
                except:
                    pass

        except:
            log_utils.log('tmdb-list0 Exception', 1)
            pass

        try:
            if tmdb == '0': raise Exception()

            seasons_url = self.tmdb_show_link % (tmdb, self.lang) + ',translations'
            seasons_en_url = self.tmdb_show_link % (tmdb, 'en')
            seasons_lite_url = self.tmdb_show_lite_link % tmdb
            if self.lang == 'en':
                url = seasons_en_url
            elif lite == True:
                url = seasons_lite_url
            else:
                url = seasons_url
            r = self.session.get(url, timeout=10)
            r.raise_for_status()
            r.encoding = 'utf-8'
            item = r.json() if six.PY3 else utils.json_loads_as_str(r.text)
            #log_utils.log('tmdb_item: ' + str(item))

            if imdb == '0':
                try:
                    imdb = item['external_ids']['imdb_id']
                    if not imdb: imdb = '0'
                except:
                    pass

            try:
                tvdb = item['external_ids']['tvdb_id']
                if not tvdb: tvdb = '0'
                else: tvdb = str(tvdb)
            except:
                tvdb = '0'

            seasons = item['seasons']
            if self.specials == 'false':
                seasons = [s for s in seasons if not s['season_number'] == 0]
            else:
                seasons.sort(key=lambda i: (i['season_number'] == 0, i['season_number']))

            try: studio = item['networks'][0]['name']
            except: studio = ''
            if not studio: studio = '0'

            try:
                genres = item['genres']
                genre = [d['name'] for d in genres]
                genre = ' / '.join(genre)
            except:
                genre = ''
            if not genre: genre = '0'

            try:
                duration = item['episode_run_time'][0]
                duration = str(duration)
            except: duration = ''
            if not duration: duration = '0'

            try:
                m = item['content_ratings']['results']
                mpaa = [d['rating'] for d in m if d['iso_3166_1'] == 'US'][0]
            except: mpaa = ''
            if not mpaa: mpaa = '0'

            try: status = item['status']
            except: status = ''
            if not status: status = '0'

            castwiththumb = []
            try:
                c = item['aggregate_credits']['cast'][:30]
                for person in c:
                    _icon = person['profile_path']
                    icon = self.tmdb_img_link % ('185', _icon) if _icon else ''
                    castwiththumb.append({'name': person['name'], 'role': person['roles'][0]['character'], 'thumbnail': icon})
            except:
                pass
            if not castwiththumb: castwiththumb = '0'

            try: show_plot = item['overview']
            except: show_plot = ''
            if not show_plot: show_plot = '0'

            if not self.lang == 'en' and show_plot == '0':
                try:
                    translations = item['translations']['translations']
                    trans_item = [x['data'] for x in translations if x['iso_639_1'] == 'en'][0]
                    show_plot = trans_item['overview']
                except:
                    pass

            unaired = ''

            try: poster_path = item['poster_path']
            except: poster_path = ''
            if poster_path: show_poster = self.tmdb_img_link % ('500', poster_path)
            else: show_poster = '0'

            try: fanart_path = item['backdrop_path']
            except: fanart_path = ''
            if fanart_path: show_fanart = self.tmdb_img_link % ('1280', fanart_path)
            else: show_fanart = '0'

            meta_poster = meta_fanart = None
            banner = clearlogo = clearart = landscape = '0'

            if meta:
                meta = json.loads(urllib_parse.unquote_plus(meta))
                #log_utils.log('seas_meta: ' + repr(meta))
                meta_poster, meta_fanart, banner, clearlogo, clearart, landscape = meta['poster'], meta['fanart'], meta['banner'], meta['clearlogo'], meta['clearart'], meta['landscape']
                if 'blacklodge.artwork' in meta_poster: meta_poster = None
                if 'blacklodge.artwork' in meta_fanart: meta_fanart = None

        except:
            log_utils.log('tmdb-list1 Exception', 1)
            return

        for s_item in seasons:
            try:
                #log_utils.log(s_item)
                season = str(s_item['season_number'])

                total_episodes = str(s_item.get('episode_count', '0'))

                premiered = s_item['air_date'] or '0'
                if status == 'Ended': pass
                elif (int(re.sub('[^0-9]', '', str(premiered))) > int(re.sub('[^0-9]', '', str(self.today_date)))) or total_episodes == '0':
                    unaired = 'true'
                    if self.showunaired != 'true': raise Exception()

                plot = s_item['overview']
                if not plot: plot = show_plot

                poster_path = s_item['poster_path']
                if poster_path: season_poster = self.tmdb_img_link % ('500', poster_path)
                else: season_poster = None

                poster = season_poster or meta_poster or show_poster
                fanart = meta_fanart or show_fanart

                self.list.append({'season': season, 'tvshowtitle': tvshowtitle, 'year': year, 'premiered': premiered, 'status': status, 'studio': studio, 'genre': genre,
                                  'duration': duration, 'mpaa': mpaa, 'castwiththumb': castwiththumb, 'plot': plot, 'imdb': imdb, 'tmdb': tmdb, 'tvdb': tvdb,
                                  'poster': poster, 'fanart': fanart, 'banner': banner,'clearlogo': clearlogo, 'clearart': clearart, 'landscape': landscape,
                                  'unaired': unaired, 'total_episodes': total_episodes, 'mediatype': 'season'})
            except:
                log_utils.log('seasons_dir Exception', 1)
                pass

        return self.list


    def seasonDirectory(self, items):
        from sys import argv
        if not items:
            control.idle()
            if not trakt.hold_notice(): control.infoDialog('No content')

        sysaddon = argv[0]

        syshandle = int(argv[1])

        addonPoster, addonFanart, addonBanner = control.addonPoster(), control.addonFanart(), control.addonBanner()

        traktCredentials = trakt.getTraktCredentialsInfo()

        kodiVersion = control.getKodiVersion()

        try:
            indicators = playcount.getTVShowIndicators()
            indicators = [i for i in indicators if i[0] == items[0]['imdb']]
        except:
            indicators = []

        # A list is shown while Trakt holds reads off: checked after the watched
        # marks (and resume points) are read, so a list that is not Trakt's but
        # shows saved marks says so too.
        if items: trakt.hold_notice()

        if self.trailer_source == '0': trailerAction = 'tmdb_trailer'
        elif self.trailer_source == '1': trailerAction = 'yt_trailer'
        else: trailerAction = 'imdb_trailer'


        watchedMenu = control.lang(32068) if trakt.getTraktIndicatorsInfo() == True else control.lang(32066)

        unwatchedMenu = control.lang(32069) if trakt.getTraktIndicatorsInfo() == True else control.lang(32067)

        queueMenu = control.lang(32065)

        traktManagerMenu = control.lang(32070)

        labelMenu = control.lang(32055)

        playRandom = control.lang(32535)

        addToLibrary = control.lang(32551)

        infoMenu = control.lang(32101)


        list_items = []
        for i in items:
            try:
                if i['season'] == '0':
                    label = 'Special Episodes'
                else:
                    label = '%s %s' % (labelMenu, i['season'])
                if i.get('unaired') == 'true':
                    label = '[COLOR crimson][I]%s[/I][/COLOR]' % label

                systitle = urllib_parse.quote_plus(i['tvshowtitle'])

                poster = i['poster'] if 'poster' in i and not i['poster'] == '0' else addonPoster
                fanart = i['fanart'] if 'fanart' in i and not i['fanart'] == '0' else addonFanart
                banner1 = i.get('banner', '')
                banner = banner1 or fanart or addonBanner
                if 'landscape' in i and not i['landscape'] == '0':
                    landscape = i['landscape']
                else:
                    landscape = fanart

                imdb, tvdb, tmdb, year, season = i.get('imdb', ''), i.get('tvdb', ''), i['tmdb'], i['year'], i['season']

                ep_meta = {'poster': poster, 'fanart': fanart, 'banner': banner, 'clearlogo': i.get('clearlogo', '0'), 'clearart': i.get('clearart', '0'), 'landscape': landscape, 'status': i.get('status', '0'), 'studio': i.get('studio', '0')}

                sysmeta = urllib_parse.quote_plus(json.dumps(ep_meta))
                #log_utils.log('sysmeta: ' + str(sysmeta))

                meta = dict((k,v) for k, v in six.iteritems(i) if not v == '0')
                meta.update({'trailer': '%s?action=%s&mode=play&name=%s&tmdb=%s&imdb=%s&season=%s' % (sysaddon, trailerAction, systitle, tmdb, imdb, season)})
                if not 'duration' in meta or meta['duration'] in ['0', 'None']: meta.update({'duration': '45'})
                try: meta.update({'duration': str(int(meta['duration']) * 60)})
                except: pass
                try: meta.update({'genre': cleangenre.lang(meta['genre'], self.lang)})
                except: pass
                try:
                    season_year = re.findall(r'(\d{4})', i['premiered'])[0]
                    meta.update({'year': season_year})
                except:
                    season_year = year

                meta.update({'mediatype': 'season', 'season': season, 'title': label, 'tvshowtitle': i['tvshowtitle'], 'imdbnumber': imdb, 'code': tmdb, 'poster': poster, 'fanart': fanart, 'banner': banner, 'landscape': landscape})

                try:
                    season_indicators = [i for i in indicators[0][2] if i[0] == int(season)]
                    overlay = 7 if len(season_indicators) >= int(i['total_episodes']) else 6
                    if overlay == 7: meta.update({'playcount': 1, 'overlay': 7})
                    else: meta.update({'playcount': 0, 'overlay': 6})
                except:
                    season_indicators = []
                    meta.update({'playcount': 0, 'overlay': 6})

                sys_meta = urllib_parse.quote_plus(json.dumps(meta))

                url = '%s?action=episodes&tvshowtitle=%s&year=%s&imdb=%s&tmdb=%s&meta=%s&season=%s' % (sysaddon, systitle, year, imdb, tmdb, sysmeta, season)

                cm = []

                cm.append((playRandom, 'RunPlugin(%s?action=random&rtype=episode&tvshowtitle=%s&year=%s&imdb=%s&tmdb=%s&season=%s)' % (sysaddon, urllib_parse.quote_plus(systitle), urllib_parse.quote_plus(year), urllib_parse.quote_plus(imdb), urllib_parse.quote_plus(tmdb), urllib_parse.quote_plus(season))))

                cm.append((queueMenu, 'RunPlugin(%s?action=queueItem)' % sysaddon))

                cm.append(('[I]Videos[/I]', 'RunPlugin(%s?action=%s&mode=select&name=%s&tmdb=%s&imdb=%s&season=%s)' % (sysaddon, trailerAction, systitle, tmdb, imdb, season)))

                cm.append((watchedMenu, 'RunPlugin(%s?action=tvPlaycount&name=%s&imdb=%s&tmdb=%s&season=%s&query=7&meta=%s)' % (sysaddon, systitle, imdb, tmdb, season, sys_meta)))

                cm.append((unwatchedMenu, 'RunPlugin(%s?action=tvPlaycount&name=%s&imdb=%s&tmdb=%s&season=%s&query=6&meta=%s)' % (sysaddon, systitle, imdb, tmdb, season, sys_meta)))

                if traktCredentials == True:
                    cm.append((traktManagerMenu, 'RunPlugin(%s?action=traktManager&name=%s&tmdb=%s&content=tvshow)' % (sysaddon, systitle, tmdb)))

                if kodiVersion < 17:
                    cm.append((infoMenu, 'Action(Info)'))

                cm.append((addToLibrary, 'RunPlugin(%s?action=tvshowToLibrary&tvshowtitle=%s&year=%s&imdb=%s&tmdb=%s)' % (sysaddon, systitle, year, imdb, tmdb)))

                art = {'icon': poster, 'thumb': poster, 'poster': poster, 'fanart': fanart, 'banner': banner, 'landscape': landscape}

                if 'clearlogo' in i and not i['clearlogo'] == '0':
                    art.update({'clearlogo': i['clearlogo']})

                if 'clearart' in i and not i['clearart'] == '0':
                    art.update({'clearart': i['clearart']})

                try: item = control.item(label=label, offscreen=True)
                except: item = control.item(label=label)

                total_episodes = i.get('total_episodes', '0')
                watched_episodes = len(season_indicators)
                try: season_progress = int((float(watched_episodes)/int(total_episodes))*100) or 0
                except: season_progress = 0
                try: unwatched_episodes = int(total_episodes) - watched_episodes
                except: unwatched_episodes = total_episodes

                item.setProperties({'TotalEpisodes': total_episodes, 'WatchedEpisodes': str(watched_episodes), 'UnWatchedEpisodes': str(unwatched_episodes),
                                    'WatchedProgress': str(season_progress)})
                item.setArt(art)
                item.addContextMenuItems(cm)

                control.processListItem(item, meta)

                #control.addItem(handle=syshandle, url=url, listitem=item, isFolder=True)
                list_items.append((url, item, True))
            except:
                log_utils.log('season-dir Exception', 1)
                pass

        control.addItems(handle=syshandle, items=list_items, totalItems=len(list_items))
        try: control.property(syshandle, 'showplot', items[0]['plot'])
        except: pass
        control.content(syshandle, 'seasons')
        control.directory(syshandle, cacheToDisc=True)
        control.sleep(1000)
        views.setView('seasons', {'skin.estuary': 55, 'skin.confluence': 500})


class episodes:
    def __init__(self):
        self.list = []

        self.session = requests.Session()

        self.trakt_link = 'https://api.trakt.tv'
        self.tvmaze_link = 'https://api.tvmaze.com'
        self.local_link = 'https://www.local.bm'
        self.datetime = datetime.datetime.utcnow()# - datetime.timedelta(hours = 5)
        self.systime = self.datetime.strftime('%Y%m%d%H%M%S%f')
        self.today_date = self.datetime.strftime('%Y-%m-%d')
        self.trakt_user = control.setting('trakt.user').strip()
        self.showunaired = control.setting('showunaired') or 'true'
        self.specials = control.setting('tv.specials') or 'true'
        self.lang = control.apiLanguage()['tmdb'] or 'en'
        self.hq_artwork = control.setting('hq.artwork') or 'false'
        self.items_per_page = str(control.setting('items.per.page')) or '20'
        self.trailer_source = control.setting('trailer.source') or '2'

        self.tmdb_user = control.setting('tm.user') or api_keys.tmdb_key
        self.tmdb_season_link = 'https://api.themoviedb.org/3/tv/%s/season/%s?api_key=%s&language=%s&append_to_response=aggregate_credits' % ('%s', '%s', self.tmdb_user, '%s')
        self.tmdb_season_lite_link = 'https://api.themoviedb.org/3/tv/%s/season/%s?api_key=%s&language=en' % ('%s', '%s', self.tmdb_user)
        self.tmdb_episode_link = 'https://api.themoviedb.org/3/tv/%s/season/%s/episode/%s?api_key=%s&language=%s&append_to_response=credits' % ('%s', '%s', '%s', self.tmdb_user, self.lang)
        self.tmdb_by_imdb = 'https://api.themoviedb.org/3/find/%s?api_key=%s&external_source=imdb_id' % ('%s', self.tmdb_user)
        self.tmdb_img_link = 'https://image.tmdb.org/t/p/w%s%s'
        self.search_link = 'https://api.themoviedb.org/3/search/tv?api_key=%s&language=en-US&query=%s&page=1' % (self.tmdb_user, '%s')

        self.fanart_tv_art_link = 'http://webservice.fanart.tv/v3/tv/%s'
        self.fanart_tv_user = control.setting('fanart.tv.user')

        self.added_link = 'https://api.tvmaze.com/schedule'
        self.calendar_link = 'https://api.tvmaze.com/schedule?date=%s'
        #https://api.trakt.tv/calendars/all/shows/date[30]/31 #use this for new episodes?
        #self.mycalendar_link = 'https://api.trakt.tv/calendars/my/shows/date[29]/60/'
        self.mycalendar_link = 'https://api.trakt.tv/calendars/my/shows/date[30]/31/' #go back 30 and show all shows aired until tomorrow
        self.trakthistory_link = 'https://api.trakt.tv/users/me/history/shows?limit=50&page=1'
        self.progresswatched_link = 'https://api.trakt.tv/users/me/watched/shows?page=1&limit=100&extended=progress|watched'
        self.progressaired_link = 'https://api.trakt.tv/users/me/watched/shows?page=1&limit=100&extended=progress|aired'
        self.hiddenprogress_link = 'https://api.trakt.tv/users/hidden/progress_watched?limit=1000&type=show'
        self.progresssync_link = 'https://api.trakt.tv/sync/progress/watched?page=1&limit=100'
        self.traktondeck_link = 'https://api.trakt.tv/sync/playback/episodes'
        self.traktlists_link = 'https://api.trakt.tv/users/me/lists'
        self.traktlikedlists_link = 'https://api.trakt.tv/users/likes/lists?page=1&limit=100'
        self.traktlist_link = 'https://api.trakt.tv/users/%s/lists/%s/items?limit=250&page=1'

        ## Local bookmarks pseudo-links ##
        self.local_history_link = 'https://www.local.bm?query=history&page=1&after='
        self.local_ondeck_link = 'https://www.local.bm?query=ondeck&page=1&after='


    def __del__(self):
        self.session.close()


    def get(self, tvshowtitle, year, imdb, tmdb, meta, season=None, episode=None, idx=True, create_directory=True):
        try:
            if idx == True:
                if season == None or episode == None:
                    self.list = cache.get(self.tmdb_list, 1, tvshowtitle, year, imdb, tmdb, season, meta)
                # elif episode == None:
                    # self.list = cache.get(self.tmdb_list, 1, tvshowtitle, year, imdb, tmdb, fanart, duration, status, season)
                else:
                    self.list = cache.get(self.tmdb_list, 1, tvshowtitle, year, imdb, tmdb, season, meta)
                    num = [x for x,y in enumerate(self.list) if y['season'] == str(season) and y['episode'] == str(episode)][-1]
                    self.list = [y for x,y in enumerate(self.list) if x >= num]

                if create_directory == True: self.episodeDirectory(self.list)
                return self.list

            else:
                self.list = self.tmdb_list(tvshowtitle, year, imdb, tmdb, season, lite=True)
                return self.list
        except:
            log_utils.log('episodes_get Exception', 1)
            pass


    def calendar(self, url):
        try:

            try: url = getattr(self, url + '_link')
            except: pass

            # blist (cached) supplies the artwork/metadata already built, the
            # list itself is always fresh. When the first call had to build the
            # list (empty or expired cache), it is fresh already and used as is
            # instead of building the same list a second time. self.built is set
            # by trakt_progress_list / trakt_episodes_list when they run.
            self.built = False
            if self.trakt_link in url and '/watched/' in url:
                self.blist = cache.get(self.trakt_progress_list, 720, url)
                self.list = []
                self.list = self.blist if (self.built and self.blist) else cache.get(self.trakt_progress_list, 0, url)

            elif self.trakt_link in url and url == self.mycalendar_link:
                self.blist = cache.get(self.trakt_episodes_list, 720, url)
                self.list = []
                self.list = self.blist if (self.built and self.blist) else cache.get(self.trakt_episodes_list, 0, url)
                self.list = sorted(self.list, key=lambda k: k['premiered'], reverse=True)
                # "New Episodes" from the Trakt calendar: hide episodes already
                # watched (the same check that draws the tick).
                try:
                    indicators = playcount.getTVShowIndicators()
                    self.list = [i for i in self.list if playcount.getEpisodeOverlay(indicators, i['imdb'], i['tmdb'], i['season'], i['episode']) != '7']
                except:
                    pass

            elif self.trakt_link in url and url == self.traktondeck_link:
                self.blist = cache.get(self.trakt_episodes_list, 720, url)
                self.list = []
                self.list = self.blist if (self.built and self.blist) else cache.get(self.trakt_episodes_list, 0, url)
                self.list = sorted(self.list, key=lambda k: int(k['paused_at']), reverse=True)

            elif self.trakt_link in url and url.split('?')[0] == self.trakthistory_link.split('?')[0]:
                self.trakt_raw_count = 0
                self.blist = cache.get(self.trakt_episodes_list, 720, url)
                self.list = []
                if self.built and self.blist:
                    self.list = self.blist
                else:
                    self.trakt_raw_count = 0
                    self.list = cache.get(self.trakt_episodes_list, 0, url)
                self.list = sorted(self.list, key=lambda k: int(k['watched_at']), reverse=True)
                # Next page when Trakt returned a full page (history is paginated).
                try:
                    q = dict(urllib_parse.parse_qsl(urllib_parse.urlsplit(url).query))
                    if self.list and self.trakt_raw_count >= int(q['limit']):
                        q['page'] = str(int(q['page']) + 1)
                        self.list[0]['next'] = url.split('?')[0] + '?' + urllib_parse.urlencode(q)
                        self.list[0]['page'] = str(int(q['page']) - 1)
                except:
                    pass

            elif self.trakt_link in url and '/users/' in url:
                self.list = cache.get(self.trakt_list, 1, url)
                self.list = self.list[::-1]

            elif self.trakt_link in url:
                self.list = cache.get(self.trakt_list, 1, url)

            elif self.tvmaze_link in url and url == self.added_link:
                urls = [i['url'] for i in self.calendars(idx=False)][:5]
                self.list = []
                for url in urls:
                    self.list += cache.get(self.tvmaze_list, 720, url, 'True')

            elif self.tvmaze_link in url:
                self.list = cache.get(self.tvmaze_list, 1, url, 'False')

            elif self.local_link in url:
                self.list = self.local_list(url)


            self.episodeDirectory(self.list)
            return self.list
        except:
            log_utils.log('calendar_get', 1)
            pass


    def widget(self):
        if trakt.getTraktIndicatorsInfo() == True:
            setting = control.setting('tv.widget.alt')
        else:
            setting = control.setting('tv.widget')

        if setting == '2':
            self.calendar(self.progresswatched_link)
        elif setting == '3':
            self.calendar(self.mycalendar_link)
        else:
            self.calendar(self.added_link)


    def calendars(self, idx=True):
        m = control.lang(32060).split('|')
        try: months = [(m[0], 'January'), (m[1], 'February'), (m[2], 'March'), (m[3], 'April'), (m[4], 'May'), (m[5], 'June'), (m[6], 'July'), (m[7], 'August'), (m[8], 'September'), (m[9], 'October'), (m[10], 'November'), (m[11], 'December')]
        except: months = []

        d = control.lang(32061).split('|')
        try: days = [(d[0], 'Monday'), (d[1], 'Tuesday'), (d[2], 'Wednesday'), (d[3], 'Thursday'), (d[4], 'Friday'), (d[5], 'Saturday'), (d[6], 'Sunday')]
        except: days = []

        for i in range(0, 30):
            try:
                name = (self.datetime - datetime.timedelta(days = i))
                name = (control.lang(32062) % (name.strftime('%A'), six.ensure_str(name.strftime('%d %B'))))
                for m in months: name = name.replace(m[1], m[0])
                for d in days: name = name.replace(d[1], d[0])
                try: name = six.ensure_str(name)
                except: pass

                url = self.calendar_link % (self.datetime - datetime.timedelta(days = i)).strftime('%Y-%m-%d')

                self.list.append({'name': name, 'url': url, 'image': 'calendar.png', 'action': 'calendar'})
            except:
                pass
        if idx == True: self.addDirectory(self.list)
        return self.list


    def userlists(self):
        userlists = []

        try:
            if trakt.getTraktCredentialsInfo() == False: raise Exception()

            try:
                activity = trakt.getActivity()
            except:
                pass

            try:
                try:
                    if activity > cache.timeout(self.trakt_user_list, self.traktlists_link): raise Exception()
                    userlists += cache.get(self.trakt_user_list, 720, self.traktlists_link)
                except:
                    userlists += cache.get(self.trakt_user_list, 0, self.traktlists_link)
            except:
                pass

            try:
                self.list = []
                try:
                    if activity > cache.timeout(self.trakt_user_list, self.traktlikedlists_link): raise Exception()
                    userlists += cache.get(self.trakt_user_list, 720, self.traktlikedlists_link)
                except:
                    userlists += cache.get(self.trakt_user_list, 0, self.traktlikedlists_link)
            except:
                pass
        except:
            pass

        self.list = userlists
        for i in range(0, len(self.list)):
            self.list[i].update({'image': 'userlists.png', 'action': 'calendar'})
        self.addDirectory(self.list, queue=True)
        return self.list


    def trakt_list(self, url, translate=True):
        # translate=False: the caller takes the title and plot from TMDb in the
        # user's language (trakt_episodes_list), so the per-episode Trakt
        # translation would be one request per episode thrown away.
        try:
            for i in re.findall(r'date\[(\d+)\]', url):
                url = url.replace('date[%s]' % i, (self.datetime - datetime.timedelta(days = int(i))).strftime('%Y-%m-%d'))

            q = dict(urllib_parse.parse_qsl(urllib_parse.urlsplit(url).query))
            q.update({'extended': 'full'})
            q = (urllib_parse.urlencode(q)).replace('%2C', ',')
            u = url.replace('?' + urllib_parse.urlparse(url).query, '') + '?' + q

            itemlist = []
            # User list items are paginated (Trakt caps limit at 250): fetch
            # every page instead of the first one.
            if '/lists/' in u and '/items' in u:
                items = trakt.getPaginatedResponse(u)
            else:
                items = trakt.getTrakt(u)
            # Raw page size before filtering, used to decide on a next page.
            self.trakt_raw_count = len(items) if isinstance(items, list) else 0
            # Failed read: None (not an empty list), so cache.get() keeps the
            # previous list. Iterating None raised before, and the list came
            # back empty ("No content").
            if not isinstance(items, list): return None
            # Resume points: only the newest 100 are shown, so only those are
            # built (one translation call each for non-English users).
            if '/sync/playback' in u and len(items) > 100:
                items = sorted(items, key=lambda k: k.get('paused_at') or '', reverse=True)[:100]
        except:
            log_utils.log('trakt_list0', 1)
            return


        for pos, item in enumerate(items):
            try:
                title = item['episode']['title']
                if title == None or title == '': raise Exception()
                title = client.replaceHTMLCodes(title)

                season = item['episode']['season']
                season = re.sub('[^0-9]', '', '%01d' % int(season))
                if season == '0' and self.specials != 'true': raise Exception()

                episode = item['episode']['number']
                episode = re.sub('[^0-9]', '', '%01d' % int(episode))
                if episode == '0': raise Exception()

                tvshowtitle = item['show']['title']
                if not tvshowtitle: raise Exception()
                else: tvshowtitle = client.replaceHTMLCodes(six.ensure_str(tvshowtitle))

                year = item['show']['year']
                year = re.sub('[^0-9]', '', str(year))

                imdb = item['show']['ids']['imdb']
                if imdb == None or imdb == '': imdb = '0'
                else: imdb = 'tt' + re.sub('[^0-9]', '', str(imdb))

                tvdb = item['show']['ids']['tvdb']
                if not tvdb: tvdb == '0'
                tvdb = re.sub('[^0-9]', '', str(tvdb))

                tmdb = item['show']['ids']['tmdb']
                if not tmdb: raise Exception()
                tmdb = str(tmdb)

                premiered = item['episode']['first_aired']
                try: premiered = re.compile(r'(\d{4}-\d{2}-\d{2})').findall(premiered)[0]
                except: premiered = '0'

                studio = item['show']['network']
                if not studio: studio = '0'

                genre = item['show']['genres']
                genre = [i.title() for i in genre]
                if not genre: genre = '0'
                else: genre = ' / '.join(genre)

                try: duration = str(item['show']['runtime'])
                except: duration = ''
                if not duration: duration = '0'

                try: rating = str(item['episode']['rating'])
                except: rating = '0'
                if rating == None or rating == '0.0': rating = '0'

                try: votes = str(item['episode']['votes'])
                except: votes = '0'
                try: votes = str(format(int(votes),',d'))
                except: pass
                if not votes: votes = '0'

                mpaa = item['show']['certification']
                if not mpaa: mpaa = '0'

                try: plot = item['episode']['overview']
                except: plot = ''
                if not plot: plot = item['show']['overview']
                if not plot: plot = '0'
                else: plot = client.replaceHTMLCodes(six.ensure_str(plot, errors='replace'))

                paused_at = item.get('paused_at', '0') or '0'
                paused_at = re.sub('[^0-9]+', '', paused_at)

                watched_at = item.get('watched_at', '0') or '0'
                watched_at = re.sub('[^0-9]+', '', watched_at)

                try:
                    # By IMDb id (the key of the translations already
                    # saved); by the show's Trakt id when there is no IMDb id,
                    # instead of asking for '/shows/0/...' (a 404 on every open).
                    trakt_id = imdb if imdb != '0' else str(item['show']['ids'].get('trakt') or '')
                    if self.lang == 'en' or not translate or not trakt_id: raise Exception()

                    # One Trakt call per episode, so cached for 7 days, also when
                    # there is no translation (new episodes are often translated a
                    # few days after they air, so not longer than that).
                    # Long user lists: Trakt is asked only for the first 100
                    # episodes (one request each); the rest use a translation
                    # already saved, if any.
                    if pos >= 100 and time.time() - cache.timeout(trakt.getEpisodeTranslation, trakt_id, self.lang, season, episode) >= 168 * 3600: raise Exception()
                    trans_item = cache.get(trakt.getEpisodeTranslation, 168, trakt_id, self.lang, season, episode)
                    if not trans_item: raise Exception()

                    title = client.replaceHTMLCodes(six.ensure_str(trans_item.get('title'))) or title
                    plot = client.replaceHTMLCodes(six.ensure_str(trans_item.get('overview'), errors='replace')) or plot

                    #tvshowtitle = trakt.getTVShowTranslation(imdb, lang=self.lang) or tvshowtitle
                except:
                    pass

                itemlist.append({'title': title, 'season': season, 'episode': episode, 'tvshowtitle': tvshowtitle, 'year': year, 'premiered': premiered, 'status': 'Continuing',
                                 'studio': studio, 'genre': genre, 'duration': duration, 'rating': rating, 'votes': votes, 'mpaa': mpaa, 'plot': plot, 'imdb': imdb, 'imdbnumber': imdb,
                                 'tvdb': tvdb, 'tmdb': tmdb, 'poster': '0', 'thumb': '0', 'paused_at': paused_at, 'watched_at': watched_at, 'list_prov': 'trakt', 'mediatype': 'episode',
                                 'playback_id': str(item.get('id', '')) if item.get('paused_at') else ''})
            except:
                log_utils.log('trakt_list1', 1)
                pass

        itemlist = itemlist[::-1]
        return itemlist


    def _trakt_paginated(self, url):
        # A list (possibly empty) when Trakt data is available, from Trakt or
        # from the cache; None when it is not.
        try:
            reads = getattr(cache, 'TRAKT_READS', {'ok': 0, 'fail': 0})
            fails = reads['fail']
            saved = cache.timeout(trakt.getPaginatedResponse, url)
            # Every 6 hours anyway: newly aired episodes change the progress
            # without any activity on the account.
            hours = trakt.refresh_timeout(trakt.getWatchedActivity() > saved, saved, url, every=6,
                                          current=lambda: cache.timeout(trakt.getPaginatedResponse, url))
            try: result = cache.get(trakt.getPaginatedResponse, hours, url)
            finally: trakt.refresh_done(url)
            if not isinstance(result, list): return None
            # cache.get() also returns [] when the read failed and nothing was
            # cached: that is not an empty progress.
            if not result and reads['fail'] > fails: return None
            # Data is available even when it came from the cache without any
            # read in this run: mark it, so cache.get() of the progress list
            # accepts a genuinely empty result (e.g. every show completed)
            # instead of showing the previous list.
            reads['ok'] += 1
            return result
        except:
            return None


    def _trakt_date(self, value):
        try: return datetime.datetime.strptime(str(value)[:19], '%Y-%m-%dT%H:%M:%S')
        except: return None


    def _trakt_watched_map(self):
        # The same watched data the ticks come from (/users/me/watched/shows,
        # cached by trakt.cachesyncTVShows), refreshed when Trakt reports
        # newer watch activity. imdb -> (aired_episodes, [(season, episode)]).
        try:
            saved = trakt.timeoutsyncTVShows()
            timeout = trakt.refresh_timeout(trakt.getWatchedActivity() > saved, saved, 'shows', every=6,
                                            current=trakt.timeoutsyncTVShows)
            try: data = trakt.cachesyncTVShows(timeout=timeout) or []
            finally: trakt.refresh_done('shows')
            # Shows without an IMDb id all carry 'None': left out, so they never
            # pick up another show's watched data (they use the bulk fallback).
            return dict((str(i[0]), (int(i[1]), i[2])) for i in data if i[0] and str(i[0]) not in ('None', '0'))
        except:
            return {}


    def _trakt_hidden(self, url):
        # For cache.get(): a dict, also when nothing is hidden (an empty list
        # would not be cached); None when the call failed.
        result = trakt.getTrakt(url)
        if not isinstance(result, list): return None
        return {'tmdb': [str(i['show']['ids']['tmdb']) for i in result if i.get('show')]}


    def _trakt_progress_items(self, result, watched=None):
        # /sync/progress/watched returns the next episode as Trakt computes it,
        # including its air date. Items are built with the same keys the legacy
        # /users/me/watched/shows path produces, so items_list() is unchanged.
        items = []
        for item in result:
            try:
                show = item['show']
                progress = item.get('progress') or {}
                last_episode = progress.get('last_episode') or {}
                next_episode = progress.get('next_episode') or {}
                if not last_episode: raise Exception()

                aired = int(progress.get('aired') or show.get('aired_episodes') or 0)
                completed = int(progress.get('completed') or 0)
                snum, enum = last_episode['season'], last_episode['number']

                # Which episode to show and whether the show is complete come
                # from the watched data, exactly like the legacy path (highest
                # watched episode, specials excluded). The bulk endpoint is a
                # cached snapshot: it reported S02E02 as the last episode of a
                # show watched up to S02E08, so its +1 was an episode already
                # watched and appeared ticked. It is only the fallback.
                imdb_id = show.get('ids', {}).get('imdb')
                w = (watched or {}).get(str(imdb_id)) if imdb_id else None
                if w:
                    eps = [(int(x[0]), int(x[1])) for x in w[1] if int(x[0]) > 0]
                    if eps:
                        snum, enum = max(eps)
                        completed, aired = len(eps), int(w[0])

                # Same rule as the legacy path: a fully watched show is not
                # listed. next_episode is never used for this.
                if completed >= aired: raise Exception()
                next_aired = self._trakt_date(next_episode.get('first_aired'))
                if next_aired and next_aired > self.datetime: next_aired = None

                tvshowtitle = show['title']
                if not tvshowtitle: raise Exception()
                else: tvshowtitle = client.replaceHTMLCodes(six.ensure_str(tvshowtitle))

                year = re.sub('[^0-9]', '', str(show.get('year')))
                if int(year) > int(self.datetime.strftime('%Y')): raise Exception()

                ids = show.get('ids') or {}
                imdb = ids.get('imdb') or '0'
                tvdb = re.sub('[^0-9]', '', str(ids.get('tvdb') or '')) or '0'
                tmdb = str(ids.get('tmdb') or '0')

                last_watched = progress.get('last_watched_at')
                if not last_watched: last_watched = '0'
                else: last_watched = re.sub('[^0-9]+', '', last_watched)

                # Latest activity: the newer of last watched and the air date of
                # the next episode, the air date only once it has aired.
                activity = self._trakt_date(progress.get('last_watched_at'))
                if next_aired and (not activity or next_aired > activity):
                    activity = next_aired
                activity = activity.strftime('%Y%m%d%H%M%S') if activity else '0'

                # status stays '0' exactly like the legacy path, which never
                # receives a status from /users/me/watched/shows.
                items.append({'imdb': imdb, 'tvdb': tvdb, 'tmdb': tmdb, 'tvshowtitle': tvshowtitle, 'year': year,
                              'snum': str(snum), 'enum': str(enum),
                              'status': '0', 'last_watched': last_watched, 'activity': activity})
            except:
                pass
        return items


    def trakt_progress_list(self, url):
        self.built = True
        # url is '<link>|<query>' or '<link>|<query>|<page>' for later pages.
        parts = url.split('|')
        url, query = parts[0], parts[1]
        try: page = max(1, int(parts[2]))
        except: page = 1
        items = []
        latest_activity = query == 'watched' and control.setting('tv.progress.latest') == 'true'

        result = self._trakt_paginated(self.progresssync_link)
        # An empty bulk answer also goes to the legacy path (the bulk endpoint is
        # a cached snapshot); an empty legacy answer is a genuinely empty
        # progress, None there is a failure.
        legacy = not result
        if not legacy:
            items = self._trakt_progress_items(result, self._trakt_watched_map())
            if latest_activity:
                items = sorted(items, key=lambda k: k['activity'], reverse=True)
            else:
                items = sorted(items, key=lambda k: k['last_watched'], reverse=True)
        else:
            result = self._trakt_paginated(url)
            if result is None: return

        for item in (result if legacy else []):
            try:
                num_1 = 0
                for i in range(0, len(item['seasons'])):
                    if item['seasons'][i]['number'] > 0: num_1 += len(item['seasons'][i]['episodes'])
                num_2 = int(item['show']['aired_episodes'])
                if num_1 >= num_2: raise Exception()

                season = str(item['seasons'][-1]['number'])

                episode = [x for x in item['seasons'][-1]['episodes'] if 'number' in x]
                episode = sorted(episode, key=lambda x: x['number'])
                episode = str(episode[-1]['number'])

                tvshowtitle = item['show']['title']
                if not tvshowtitle: raise Exception()
                else: tvshowtitle = client.replaceHTMLCodes(six.ensure_str(tvshowtitle))

                year = item['show']['year']
                year = re.sub('[^0-9]', '', str(year))
                if int(year) > int(self.datetime.strftime('%Y')): raise Exception()

                status = item['show'].get('status')
                if not status: status = '0'

                imdb = item['show']['ids']['imdb']
                if not imdb: imdb = '0'

                tvdb = item['show']['ids']['tvdb']
                if not tvdb: tvdb = '0'
                else: tvdb = re.sub('[^0-9]', '', str(tvdb))

                tmdb = item['show']['ids']['tmdb']
                if not tmdb: tmdb = '0'
                else: tmdb = str(tmdb)

                last_watched = item['last_watched_at']
                if last_watched == None or last_watched == '': last_watched = '0'
                else: last_watched = re.sub('[^0-9]+', '', last_watched)

                items.append({'imdb': imdb, 'tvdb': tvdb, 'tmdb': tmdb, 'tvshowtitle': tvshowtitle, 'year': year, 'snum': season, 'enum': episode,
                              'status': status, 'last_watched': last_watched})
            except:
                #log_utils.log('TProgress0', 1)
                pass

        try:
            # Hidden shows change only when the user hides one (hidden_at is in
            # getActivity()), so cached until then instead of asked on every open.
            if trakt.getActivity() > cache.timeout(self._trakt_hidden, self.hiddenprogress_link):
                result = cache.get(self._trakt_hidden, 0, self.hiddenprogress_link)
            else:
                result = cache.get(self._trakt_hidden, 720, self.hiddenprogress_link)
            result = result['tmdb']

            items = [i for i in items if not i['tmdb'] in result]
        except:
            log_utils.log('TProgress1', 1)
            pass

        def items_list(i):

            tmdb, imdb, tvdb = i['tmdb'], i['imdb'], i['tvdb']
            if (not tmdb or tmdb == '0') and not imdb == '0':
                try:
                    url = self.tmdb_by_imdb % imdb
                    result = self.session.get(url, timeout=16).json()
                    id = result['tv_results'][0]
                    tmdb = id['id']
                    if not tmdb: tmdb = '0'
                    else: tmdb = str(tmdb)
                except:
                    pass

            try:
                item = [x for x in self.blist if x['tmdb'] == tmdb and x['snum'] == i['snum'] and x['enum'] == i['enum']][0]
                item['action'] = 'episodes'
                self.list.append(item)
                return
            except:
                pass

            try:
                if tmdb == '0': raise Exception()

                _episode = str(int(i['enum']) + 1)
                _season = str(int(i['snum']) + 1)

                url = self.tmdb_episode_link % (tmdb, i['snum'], _episode)
                r = self.session.get(url, timeout=10)
                if r.json().get('status_code') == 34:
                    url2 = self.tmdb_episode_link % (tmdb, _season, '1')
                    r = self.session.get(url2, timeout=10)
                r.raise_for_status()
                r.encoding = 'utf-8'
                item = r.json() if six.PY3 else utils.json_loads_as_str(r.text)
                #log_utils.log(item)

                try: premiered = item['air_date']
                except: premiered = ''
                if not premiered: premiered = '0'

                unaired = ''
                if i['status'] == 'Ended': pass
                elif premiered == '0': raise Exception()
                elif int(re.sub(r'[^0-9]', '', str(premiered))) > int(re.sub(r'[^0-9]', '', str(self.today_date))):
                    unaired = 'true'
                    raise Exception()

                title = item['name']
                if not title: title = '0'

                season = str(item['season_number'])

                episode = item['episode_number']
                episode = '%01d' % episode

                try: still_path = item['still_path']
                except: still_path = ''
                if not still_path: thumb = '0'
                else: thumb = self.tmdb_img_link % ('300', still_path)

                try: rating = str(item['vote_average'])
                except: rating = ''
                if not rating: rating = '0'

                try: votes = str(item['vote_count'])
                except: votes = ''
                if not votes: votes = '0'

                try: plot = item['overview']
                except: plot = ''
                if not plot: plot = '0'

                duration = str(item.get('runtime') or 0)

                try:
                    r_crew = item['crew']
                    director = [d for d in r_crew if d['job'] == 'Director']
                    director = ', '.join([d['name'] for d in director])
                    writer = [w for w in r_crew if w['job'] == 'Writer']
                    writer = ', '.join([w['name'] for w in writer])
                except:
                    director = writer = ''
                if not director: director = '0'
                if not writer: writer = '0'

                castwiththumb = []
                try:
                    r_cast = item['credits']['cast'][:30]
                    for person in r_cast:
                        _icon = person['profile_path']
                        icon = self.tmdb_img_link % ('185', _icon) if _icon else ''
                        castwiththumb.append({'name': person['name'], 'role': person['character'], 'thumbnail': icon})
                except:
                    pass
                if not castwiththumb: castwiththumb = '0'

                poster = fanart = banner = landscape = clearlogo = clearart = '0'

                if not tvdb == '0':
                    poster, fanart, banner, landscape, clearlogo, clearart = self.fanart_tv_art(tvdb)

                if poster == '0':
                    try:
                        url = seasons().tmdb_show_link % (tmdb, self.lang)
                        r = requests.get(url, timeout=20)
                        r.raise_for_status()
                        r.encoding = 'utf-8'
                        tmdb_item = r.json() if six.PY3 else utils.json_loads_as_str(r.text)
                        try: poster_path = tmdb_item['poster_path']
                        except: poster_path = ''
                        if not poster_path: poster = '0'
                        else: poster = self.tmdb_img_link % ('500', poster_path)
                        try: backdrop_path = tmdb_item['backdrop_path']
                        except: backdrop_path = ''
                        if backdrop_path: fanart = self.tmdb_img_link % ('1280', backdrop_path)
                    except:
                        pass

                self.list.append({'title': title, 'season': season, 'episode': episode, 'tvshowtitle': i['tvshowtitle'], 'year': i['year'], 'premiered': premiered,
                                  'duration': duration, 'rating': rating, 'votes': votes, 'director': director, 'writer': writer,
                                  'castwiththumb': castwiththumb, 'plot': plot, 'poster': poster, 'banner': banner, 'fanart': fanart, 'thumb': thumb, 'clearlogo': clearlogo, 'clearart': clearart,
                                  'landscape': landscape, 'snum': i['snum'], 'enum': i['enum'], 'action': 'episodes', 'unaired': unaired, 'last_watched': i['last_watched'],
                                  'imdb': imdb, 'imdbnumber': imdb, 'tvdb': tvdb, 'tmdb': tmdb, 'list_prov': 'trakt', 'mediatype': 'episode'}) # '_sort_key': max(i['last_watched'], premiered)
            except:
                log_utils.log('TProgress', 1)
                pass

        # 50 shows per page: TMDb is only queried for the page being opened.
        # The full sorted list comes from the cached Trakt response.
        start = (page - 1) * 50
        has_next = len(items) > start + 50
        items = items[start:start + 50]

        threads = []
        for i in items: threads.append(workers.Thread(items_list, i))
        [i.start() for i in threads]
        [i.join() for i in threads]

        if query == 'aired':
            self.list = sorted(self.list, key=lambda k: int(re.sub('[^0-9]+', '', k['premiered'])), reverse=True)
        elif latest_activity:
            activity = dict((i['tmdb'], i.get('activity')) for i in items)
            def activity_key(k):
                value = activity.get(k.get('tmdb'))
                if value: return value
                # Legacy path or unmatched item: compare the date parts only.
                aired = re.sub('[^0-9]', '', str(k.get('premiered', '')))[:8]
                if len(aired) < 8 or aired > self.datetime.strftime('%Y%m%d'): aired = '0'
                return max(str(k.get('last_watched', '0'))[:14], aired)
            self.list = sorted(self.list, key=activity_key, reverse=True)
        else:
            self.list = sorted(self.list, key=lambda k: k['last_watched'], reverse=True)

        # Trakt answered but no item could be built (e.g. TMDb failing): None,
        # so cache.get() keeps the previous list instead of an empty one.
        if items and not self.list: return None

        if self.list:
            self.list[0]['next'] = '%s|%s|%d' % (url, query, page + 1) if has_next else ''
            self.list[0]['page'] = str(page)

        return self.list


    def trakt_episodes_list(self, url):
        self.built = True
        items = self.trakt_list(url, translate=False)
        if items is None: return None

        def items_list(i):

            tmdb, imdb, tvdb = i['tmdb'], i['imdb'], i['tvdb']
            if (not tmdb or tmdb == '0') and not imdb == '0':
                try:
                    url = self.tmdb_by_imdb % imdb
                    result = self.session.get(url, timeout=16).json()
                    id = result['tv_results'][0]
                    tmdb = id['id']
                    if not tmdb: tmdb = '0'
                    else: tmdb = str(tmdb)
                except:
                    pass

            try:
                item = [x for x in self.blist if x['tmdb'] == tmdb and x['season'] == i['season'] and x['episode'] == i['episode']][0]
                if item['thumb'] == '0': raise Exception()
                item['playback_id'] = i.get('playback_id', '')
                self.list.append(item)
                return
            except:
                pass

            try:
                if tmdb == '0': raise Exception()

                url = self.tmdb_episode_link % (tmdb, i['season'], i['episode'])
                r = self.session.get(url, timeout=16)
                r.encoding = 'utf-8'
                item = r.json() if six.PY3 else utils.json_loads_as_str(r.text)

                title = item.get('name', '')
                if not title: title = i['title']

                season = str(item['season_number'])

                episode = str(item['episode_number'])

                try: still_path = item['still_path']
                except: still_path = ''
                if not still_path: thumb = '0'
                else: thumb = self.tmdb_img_link % ('300', still_path)

                try: plot = item['overview']
                except: plot = ''
                if not plot: plot = i['plot']

                try:
                    r_crew = item['crew']
                    director = [d for d in r_crew if d['job'] == 'Director']
                    director = ', '.join([d['name'] for d in director])
                    writer = [w for w in r_crew if w['job'] == 'Writer']
                    writer = ', '.join([w['name'] for w in writer])
                except:
                    director = writer = ''
                if not director: director = '0'
                if not writer: writer = '0'

                castwiththumb = []
                try:
                    r_cast = item['credits']['cast'][:30]
                    for person in r_cast:
                        _icon = person['profile_path']
                        icon = self.tmdb_img_link % ('185', _icon) if _icon else ''
                        castwiththumb.append({'name': person['name'], 'role': person['character'], 'thumbnail': icon})
                except:
                    pass
                if not castwiththumb: castwiththumb = '0'

                tvshowtitle, year, premiered, duration, genre = i['tvshowtitle'], i['year'], i['premiered'], i['duration'], i['genre']
                rating, votes, mpaa, status, studio = i['rating'], i['votes'], i['mpaa'], i['status'], i['studio']

                paused_at = i.get('paused_at', '0') or '0'
                paused_at = re.sub('[^0-9]+', '', paused_at)

                watched_at = i.get('watched_at', '0') or '0'
                watched_at = re.sub('[^0-9]+', '', watched_at)

                poster = fanart = banner = landscape = clearlogo = clearart = '0'

                if not tvdb == '0':
                    poster, fanart, banner, landscape, clearlogo, clearart = self.fanart_tv_art(tvdb)

                if poster == '0':
                    try:
                        url = seasons().tmdb_show_link % (tmdb, self.lang)
                        r = requests.get(url, timeout=20)
                        r.raise_for_status()
                        r.encoding = 'utf-8'
                        tmdb_item = r.json() if six.PY3 else utils.json_loads_as_str(r.text)
                        try: poster_path = tmdb_item['poster_path']
                        except: poster_path = ''
                        if not poster_path: poster = '0'
                        else: poster = self.tmdb_img_link % ('500', poster_path)
                        try: backdrop_path = tmdb_item['backdrop_path']
                        except: backdrop_path = ''
                        if backdrop_path: fanart = self.tmdb_img_link % ('1280', backdrop_path)
                    except:
                        pass

                self.list.append({'title': title, 'season': season, 'episode': episode, 'tvshowtitle': tvshowtitle, 'year': year, 'premiered': premiered, 'status': status, 'studio': studio, 'genre': genre,
                                  'duration': duration, 'rating': rating, 'votes': votes, 'mpaa': mpaa, 'director': director, 'writer': writer, 'castwiththumb': castwiththumb, 'plot': plot,
                                  'imdb': imdb, 'imdbnumber': imdb, 'tvdb': tvdb, 'tmdb': tmdb, 'poster': poster, 'banner': banner, 'fanart': fanart, 'thumb': thumb, 'clearlogo': clearlogo,
                                  'clearart': clearart, 'landscape': landscape, 'paused_at': paused_at, 'watched_at': watched_at, 'list_prov': 'trakt', 'mediatype': 'episode',
                                  'playback_id': i.get('playback_id', '')})
            except:
                log_utils.log('trakt_episodes_list', 1)
                pass


        # Newest resume points first before the cap (trakt_list reverses the
        # order Trakt returns, and Continue watching now gets all of them).
        if any(i.get('paused_at', '0') not in ('0', '') for i in items):
            items = sorted(items, key=lambda k: int(k.get('paused_at') or 0), reverse=True)
        items = items[:100]

        threads = []
        for i in items: threads.append(workers.Thread(items_list, i))
        [i.start() for i in threads]
        [i.join() for i in threads]

        # Trakt answered but no item could be built (e.g. TMDb failing): None,
        # so cache.get() keeps the previous list instead of an empty one.
        if items and not self.list: return None

        return self.list


    def trakt_user_list(self, url):
        items = None
        try:
            # Liked lists are paginated (Trakt default page size is 10).
            items = trakt.getPaginatedResponse(url) if 'page=' in url else trakt.getTrakt(url)
        except:
            pass
        # Failed read: None, so cache.get() keeps the previous menu (iterating
        # None raised before and the menu came back empty).
        if not isinstance(items, list): return None

        for item in items:
            try:
                try:
                    name_list = (trakt.slug(item['list']['user']['username']), item['list']['ids']['slug'])
                    name = "  ".join((item['list']['name'], '[I](%s)[/I]' % name_list[0]))
                    desc = item['list'].get('description', '') or ''
                except:
                    name_list = ('me', item['ids']['slug'])
                    name = item['name']
                    desc = item.get('description', '') or ''

                url = self.traktlist_link % name_list

                self.list.append({'name': name, 'url': url, 'context': url, 'plot': desc})
            except:
                pass

        self.list = sorted(self.list, key=lambda k: k['name'].lower())
        return self.list


    def tvmaze_list(self, url, limit):
        try:
            try:
                r = self.session.get(url, timeout=10)
            except requests.exceptions.SSLError:
                r = self.session.get(url, verify=False)
            r.raise_for_status()
            r.encoding = 'utf-8'
            items = r.json() if six.PY3 else utils.json_loads_as_str(r.text)

            itemlist = []
        except:
            log_utils.log('tvmaze_list0', 1)
            return

        for item in items:
            try:
                if not 'english' in item['show']['language'].lower(): continue

                if limit == 'True' and not 'scripted' in item['show']['type'].lower(): continue

                title = item['name']
                if not title: raise Exception()
                title = client.replaceHTMLCodes(title)

                season = item['season']
                season = re.sub('[^0-9]', '', '%01d' % int(season))
                if season == '0': continue

                episode = item['number']
                episode = re.sub('[^0-9]', '', '%01d' % int(episode))
                if episode == '0': continue

                tvshowtitle = item['show']['name']
                if not tvshowtitle: raise Exception()
                tvshowtitle = client.replaceHTMLCodes(tvshowtitle)

                year = item['show']['premiered']
                year = re.findall(r'(\d{4})', year)[0]

                imdb = item['show']['externals']['imdb']
                if not imdb: imdb = '0'
                else: imdb = 'tt' + re.sub('[^0-9]', '', str(imdb))

                tvdb = item['show']['externals']['thetvdb']
                if not tvdb: tvdb = '0'
                tvdb = re.sub('[^0-9]', '', str(tvdb))

                try: poster1 = item['show']['image']['original']
                except: poster1 = ''
                if not poster1: poster1 = '0'

                try: thumb1 = item['image']['original']
                except: thumb1 = ''

                try: premiered = re.findall(r'(\d{4}-\d{2}-\d{2})', item['airdate'])[0]
                except: premiered = ''
                if not premiered: premiered = '0'

                try: studio1 = item['show']['network']['name']
                except: studio1 = ''
                try: studio2 = item['show']['webChannel']['name']
                except: studio2 = ''
                studio = studio1 or studio2
                if not studio: studio = '0'

                try: genre = item['show']['genres']
                except: genre = ''
                if genre:
                    genre = [i.title() for i in genre]
                    genre = ' / '.join(genre)
                else: genre = '0'

                try: duration = str(item['show']['runtime'])
                except: duration = ''
                if not duration or duration == 'None': duration = '0'

                try: rating = str(item['show']['rating']['average'])
                except: rating = ''
                if rating in [None, 'None', '0.0']: rating = '0'

                votes = '0'

                try: plot = item['show']['summary']
                except: plot = ''
                if not plot: plot = '0'
                else:
                    plot = re.sub(r'<.+?>|</.+?>|\n', '', plot)
                    plot = client.replaceHTMLCodes(plot)

                poster2 = fanart = banner = landscape = clearlogo = clearart = '0'

                if not tvdb == '0':
                    poster2, fanart, banner, landscape, clearlogo, clearart = self.fanart_tv_art(tvdb)

                poster = poster2 if not poster2 == '0' else poster1
                thumb = thumb1 or poster

                itemlist.append({'title': title, 'season': season, 'episode': episode, 'tvshowtitle': tvshowtitle, 'year': year, 'premiered': premiered, 'status': 'Continuing', 'studio': studio,
                                 'genre': genre, 'duration': duration, 'rating': rating, 'votes': votes, 'plot': plot, 'imdb': imdb, 'imdbnumber': imdb, 'tvdb': tvdb, 'tmdb': '0', 'thumb': thumb,
                                 'poster': poster, 'banner': banner, 'fanart': fanart, 'clearlogo': clearlogo, 'clearart': clearart, 'landscape': landscape, 'list_prov': 'tvmaze', 'mediatype': 'episode'})
            except:
                log_utils.log('tvmaze_list1', 1)
                pass

        itemlist = itemlist[::-1]

        return itemlist


    def local_list(self, url):
        try:
            query = re.findall(r'query=([^&]+)', url)[0]
            control.makeFile(control.dataPath)

            dbcon = database.connect(control.bookmarksFile)
            dbcur = dbcon.cursor()
            if query == 'history':
                dbcur.execute("SELECT * FROM bookmarks WHERE (type = 'episode' AND overlay = 7)")
            elif query == 'ondeck':
                dbcur.execute("SELECT * FROM bookmarks WHERE (type = 'episode' AND played_seconds > 120 AND progress < 92)")
            match = dbcur.fetchall()
            dbcon.commit()
        except:
            log_utils.log('local_list_fail', 1)
            return self.list

        if match:
            try:
                match = sorted(match, key=lambda x: x[-1], reverse=True)
                all_items = [(json.loads(m[3]), m[4], m[5]) for m in match][:100]
                for a in all_items:
                    a[0].update({'season': a[1], 'episode': a[2]})

                items = [b[0] for b in all_items]

                for i in items:
                    try:
                        i.pop('page', None) ; i.pop('next', None)
                        i.update({'duration': str(int(i['duration']) // 60), 'local': True})
                        if not 'tvshowtitle' in i: i['tvshowtitle'] = i['title']
                        if not 'rating' in i or not 'votes' in i: i['rating'] = i['votes'] = '0'
                        self.list.append(i)
                    except:
                        pass
            except:
                log_utils.log('local_list_fail', 1)
                return

        return self.list


    def fanart_tv_art(self, tvdb):
        poster = fanart = banner = landscape = clearlogo = clearart = '0'

        try:
            #if self.fanart_tv_user == '': raise Exception()
            fanart_tv_headers = {'api-key': api_keys.fanarttv_key}
            if not self.fanart_tv_user == '':
                fanart_tv_headers.update({'client-key': self.fanart_tv_user})
            r = self.session.get(self.fanart_tv_art_link % tvdb, headers=fanart_tv_headers, timeout=10)
            r.raise_for_status()
            r.encoding = 'utf-8'
            art = r.json() if six.PY3 else utils.json_loads_as_str(r.text)

            try:
                _poster = art['tvposter']
                _poster = [x for x in _poster if x.get('lang') == self.lang][::-1] + [x for x in _poster if x.get('lang') == 'en'][::-1] + [x for x in _poster if x.get('lang') in ['00', '']][::-1]
                _poster = _poster[0]['url']
                if _poster: poster = _poster
            except:
                pass

            try:
                _fanart = art['showbackground']
                _fanart = [x for x in _fanart if x.get('lang') == self.lang][::-1] + [x for x in _fanart if x.get('lang') == 'en'][::-1] + [x for x in _fanart if x.get('lang') in ['00', '']][::-1]
                _fanart = _fanart[0]['url']
                if _fanart: fanart = _fanart
            except:
                pass

            if self.hq_artwork == 'true':

                try:
                    _banner = art['tvbanner']
                    _banner = [x for x in _banner if x.get('lang') == self.lang][::-1] + [x for x in _banner if x.get('lang') == 'en'][::-1] + [x for x in _banner if x.get('lang') in ['00', '']][::-1]
                    _banner = _banner[0]['url']
                    if _banner: banner = _banner
                except:
                    pass

                try:
                    if 'hdtvlogo' in art: _clearlogo = art['hdtvlogo']
                    else: _clearlogo = art['clearlogo']
                    _clearlogo = [x for x in _clearlogo if x.get('lang') == self.lang][::-1] + [x for x in _clearlogo if x.get('lang') == 'en'][::-1] + [x for x in _clearlogo if x.get('lang') in ['00', '']][::-1]
                    _clearlogo = _clearlogo[0]['url']
                    if _clearlogo: clearlogo = _clearlogo
                except:
                    pass

                try:
                    if 'hdclearart' in art: _clearart = art['hdclearart']
                    else: _clearart = art['clearart']
                    _clearart = [x for x in _clearart if x.get('lang') == self.lang][::-1] + [x for x in _clearart if x.get('lang') == 'en'][::-1] + [x for x in _clearart if x.get('lang') in ['00', '']][::-1]
                    _clearart = _clearart[0]['url']
                    if _clearart: clearart = _clearart
                except:
                    pass

                try:
                    if 'tvthumb' in art: _landscape = art['tvthumb']
                    else: _landscape = art['showbackground']
                    _landscape = [x for x in _landscape if x.get('lang') == self.lang][::-1] + [x for x in _landscape if x.get('lang') == 'en'][::-1] + [x for x in _landscape if x.get('lang') in ['00', '']][::-1]
                    _landscape = _landscape[0]['url']
                    if _landscape: landscape = _landscape
                except:
                    pass
        except:
            #log_utils.log('fanart.tv art fail', 1)
            pass

        return poster, fanart, banner, landscape, clearlogo, clearart


    def tmdb_list(self, tvshowtitle, year, imdb, tmdb, season, meta=None, lite=False):

        if tmdb == '0' and not imdb == '0':
            try:
                url = self.tmdb_by_imdb % imdb
                result = self.session.get(url, timeout=16).json()
                id = result['tv_results'][0]
                tmdb = id['id']
                if not tmdb: tmdb = '0'
                else: tmdb = str(tmdb)
            except:
                pass

        if tmdb == '0':
            try:
                url = self.search_link % (urllib_parse.quote(tvshowtitle)) + '&first_air_date_year=' + year
                result = self.session.get(url, timeout=16).json()
                results = result['results']
                show = [r for r in results if cleantitle.get(r.get('name')) == cleantitle.get(self.list[i]['title'])][0]# and re.findall(r'(\d{4})', r.get('first_air_date'))[0] == self.list[i]['year']][0]
                tmdb = show['id']
                if not tmdb: tmdb = '0'
                else: tmdb = str(tmdb)
            except:
                pass

        try:
            if tmdb == '0': raise Exception()

            episodes_url = self.tmdb_season_link % (tmdb, season, self.lang)
            episodes_lite_url = self.tmdb_season_lite_link % (tmdb, season)
            if lite == False:
                url = episodes_url
            else:
                url = episodes_lite_url
            #log_utils.log('tmdb url: ' + repr(url))
            r = self.session.get(url, timeout=10)
            r.raise_for_status()
            r.encoding = 'utf-8'
            result = r.json() if six.PY3 else utils.json_loads_as_str(r.text)

            episodes = result['episodes']
            if self.specials == 'false':
                episodes = [e for e in episodes if not e['season_number'] == 0]
            if not episodes: raise Exception()

            r_cast = result.get('aggregate_credits', {}).get('cast', [])

            poster_path = result.get('poster_path')
            if poster_path:
                poster = self.tmdb_img_link % ('500', poster_path)
            else:
                poster = '0'

            fanart = banner = clearlogo = clearart = landscape = status = studio = '0'
            if meta:
                _meta = json.loads(urllib_parse.unquote_plus(meta))
                poster, fanart, banner, clearlogo, clearart, landscape, status, studio = _meta['poster'], _meta['fanart'], _meta['banner'], _meta['clearlogo'], _meta['clearart'], _meta['landscape'], _meta['status'], _meta['studio']

            for item in episodes:
                try:
                    season = str(item['season_number'])

                    episode = str(item['episode_number'])

                    title = item.get('name')
                    if not title: title = 'Episode %s' % episode

                    premiered = item.get('air_date')
                    if not premiered: premiered = '0'

                    unaired = ''
                    if not premiered or premiered == '0': pass
                    elif int(re.sub('[^0-9]', '', str(premiered))) > int(re.sub('[^0-9]', '', str(self.today_date))):
                        unaired = 'true'
                        if self.showunaired != 'true': raise Exception()

                    still_path = item.get('still_path')
                    if still_path:
                        thumb = self.tmdb_img_link % ('300', still_path)
                    else:
                        thumb = '0'

                    try: rating = str(item['vote_average'])
                    except: rating = ''
                    if not rating: rating = '0'

                    try: votes = str(item['vote_count'])
                    except: votes = ''
                    if not votes: votes = '0'

                    try: episodeplot = item['overview']
                    except: episodeplot = ''
                    if not episodeplot: episodeplot = '0'

                    # if not self.lang == 'en' and episodeplot == '0':
                        # try:
                            # en_item = en_result.get('episodes', [])
                            # episodeplot = en_item['overview']
                            # episodeplot = six.ensure_str(episodeplot)
                        # except:
                            # episodeplot = ''
                        # if not episodeplot: episodeplot = '0'

                    try:
                        duration = str(item['runtime'])
                    except:
                        duration = ''
                    if not duration: duration = '0'

                    try:
                        r_crew = item['crew']
                        director = [d for d in r_crew if d['job'] == 'Director']
                        director = ', '.join([d['name'] for d in director])
                        writer = [w for w in r_crew if w['job'] == 'Writer']
                        writer = ', '.join([w['name'] for w in writer])
                    except:
                        director = writer = ''
                    if not director: director = '0'
                    if not writer: writer = '0'

                    castwiththumb = []
                    try:
                        for person in r_cast[:30]:
                            _icon = person['profile_path']
                            icon = self.tmdb_img_link % ('185', _icon) if _icon else ''
                            castwiththumb.append({'name': person['name'], 'role': person['roles'][0]['character'], 'thumbnail': icon})
                    except:
                        pass
                    if not castwiththumb: castwiththumb = '0'

                    self.list.append({'title': title, 'season': season, 'episode': episode, 'tvshowtitle': tvshowtitle, 'year': year, 'premiered': premiered,
                                      'rating': rating, 'votes': votes, 'director': director, 'writer': writer, 'castwiththumb': castwiththumb, 'duration': duration, 'studio': studio,
                                      'status': status, 'plot': episodeplot, 'imdb': imdb, 'imdbnumber': imdb, 'tmdb': tmdb, 'tvdb': '0', 'unaired': unaired, 'thumb': thumb,
                                      'poster': poster, 'fanart': fanart, 'banner': banner,'clearlogo': clearlogo, 'clearart': clearart, 'landscape': landscape, 'mediatype': 'episode'})
                except:
                    log_utils.log('tmdb_list2 Exception', 1)
                    pass

            return self.list
        except:
            log_utils.log('tmdb_list1 Exception', 1)
            return self.list


    def episodeDirectory(self, items):
        from sys import argv
        if not items:
            control.idle()
            if not trakt.hold_notice(): control.infoDialog('No content')

        sysaddon = argv[0]

        syshandle = int(argv[1])

        addonPoster, addonFanart, addonBanner = control.addonPoster(), control.addonFanart(), control.addonBanner()

        traktCredentials = trakt.getTraktCredentialsInfo()

        kodiVersion = control.getKodiVersion()

        isPlayable = True if not 'plugin' in control.infoLabel('Container.PluginName') else False

        indicators = playcount.getTVShowIndicators()

        # Resume point source = Trakt: the list indicator shows Trakt's paused
        # point (the player resumes from it too), not only this device's.
        playback = trakt.playbackProgress()

        # A list is shown while Trakt holds reads off: checked after the watched
        # marks (and resume points) are read, so a list that is not Trakt's but
        # shows saved marks says so too.
        if items: trakt.hold_notice()

        if self.trailer_source == '0': trailerAction = 'tmdb_trailer'
        elif self.trailer_source == '1': trailerAction = 'yt_trailer'
        else: trailerAction = 'imdb_trailer'

        try: multi = [i['tvshowtitle'] for i in items]
        except: multi = []
        multi = len([x for y,x in enumerate(multi) if x not in multi[:y]])
        multi = True if multi > 1 else False

        try: sysaction = items[0]['action']
        except: sysaction = ''

        isFolder = False if not sysaction == 'episodes' else True

        playbackMenu = control.lang(32063) if control.setting('hosts.mode') == '2' else control.lang(32064)

        watchedMenu = control.lang(32068) if trakt.getTraktIndicatorsInfo() == True else control.lang(32066)

        unwatchedMenu = control.lang(32069) if trakt.getTraktIndicatorsInfo() == True else control.lang(32067)

        queueMenu = control.lang(32065)

        traktManagerMenu = control.lang(32070)

        tvshowBrowserMenu = control.lang(32071)

        addToLibrary = control.lang(32551)

        infoMenu = control.lang(32101)

        clearProviders = control.lang(32081)

        list_items = []
        for i in items:
            try:
                if i['title'] == '0':
                    label = '%sx%02d . %s %s' % (i['season'], int(i['episode']), 'Episode', i['episode'])
                else:
                    label = '%sx%02d . %s' % (i['season'], int(i['episode']), i['title'])
                if multi == True or 'local' in i:
                    label = '%s - %s' % (i['tvshowtitle'], label)

                try:
                    if i['unaired'] == 'true':
                        label = '[COLOR crimson][I]%s[/I][/COLOR]' % label
                except:
                    pass

                imdb, tvdb, tmdb, year, season, episode = i.get('imdb', ''), i.get('tvdb', ''), i['tmdb'], i['year'], i['season'], i['episode']

                poster = i['poster'] if 'poster' in i and not i['poster'] == '0' else addonPoster
                fanart = i['fanart'] if 'fanart' in i and not i['fanart'] == '0' else addonFanart
                banner1 = i.get('banner', '')
                banner = banner1 or fanart or addonBanner
                landscape = i['landscape'] if 'landscape' in i and not i['landscape'] == '0' else fanart

                seasons_meta = {'poster': poster, 'fanart': fanart, 'banner': banner, 'clearlogo': i.get('clearlogo', '0'), 'clearart': i.get('clearart', '0'), 'landscape': landscape, 'studio': i.get('studio', '0'), 'status': i.get('status', '0')}
                seas_meta = urllib_parse.quote_plus(json.dumps(seasons_meta))

                systitle = urllib_parse.quote_plus(i['title'])
                systvshowtitle = urllib_parse.quote_plus(i['tvshowtitle'])
                syspremiered = urllib_parse.quote_plus(i['premiered'])

                meta = dict((k,v) for k, v in six.iteritems(i) if not v == '0')
                if i.get('season') == '0': meta.update({'season': '0'})
                meta.update({'trailer': '%s?action=%s&mode=play&name=%s&tmdb=%s&imdb=%s&season=%s&episode=%s' % (sysaddon, trailerAction, systvshowtitle, tmdb, imdb, season, episode)})
                if not 'duration' in meta or meta['duration'] in ['0', 'None']: meta.update({'duration': '45'})
                try: meta.update({'duration': str(int(meta['duration']) * 60)})
                except: pass
                try: meta.update({'genre': cleangenre.lang(meta['genre'], self.lang)})
                except: pass
                try:
                    episode_year = re.findall(r'(\d{4})', i['premiered'])[0]
                    meta.update({'year': episode_year})
                except:
                    episode_year = year
                offset = bookmarks.get('episode', imdb, season, episode, True)
                if playback is not None:
                    # Same percentage as on Trakt, on the duration given to Kodi.
                    try: offset = int(playback.get('episode', {}).get('%s|%s|%s' % (imdb, int(season), int(episode)), 0) / 100.0 * int(meta['duration']))
                    except: offset = 0

                meta.update({'mediatype': 'episode', 'season': season, 'offset': offset, 'imdbnumber': imdb, 'code': tmdb,
                             'poster': poster, 'fanart': fanart, 'banner': banner, 'landscape': landscape})

                sysmeta = urllib_parse.quote_plus(json.dumps(meta))


                url = '%s?action=play&title=%s&year=%s&imdb=%s&tmdb=%s&season=%s&episode=%s&tvshowtitle=%s&premiered=%s&meta=%s&t=%s' % (sysaddon, systitle, year, imdb, tmdb, season, episode, systvshowtitle, syspremiered, sysmeta, self.systime)
                sysurl = urllib_parse.quote_plus(url)

                #path = '%s?action=play&title=%s&year=%s&imdb=%s&tmdb=%s&season=%s&episode=%s&tvshowtitle=%s&premiered=%s' % (sysaddon, systitle, year, imdb, tmdb, season, episode, systvshowtitle, syspremiered)

                if isFolder == True:
                    url = '%s?action=episodes&tvshowtitle=%s&year=%s&imdb=%s&tmdb=%s&meta=%s&season=%s&episode=%s' % (sysaddon, systvshowtitle, year, imdb, tmdb, seas_meta, season, episode)

                cm = []

                cm.append((queueMenu, 'RunPlugin(%s?action=queueItem)' % sysaddon))

                if multi == True:
                    cm.append((tvshowBrowserMenu, 'Container.Update(%s?action=seasons&tvshowtitle=%s&year=%s&imdb=%s&tmdb=%s&meta=%s,return)' % (sysaddon, systvshowtitle, year, imdb, tmdb, seas_meta)))

                cm.append(('[I]Videos[/I]', 'RunPlugin(%s?action=%s&mode=select&name=%s&tmdb=%s&imdb=%s&season=%s&episode=%s)' % (sysaddon, trailerAction, systvshowtitle, tmdb, imdb, season, episode)))

                try:
                    overlay = int(playcount.getEpisodeOverlay(indicators, imdb, tmdb, season, episode))
                    if overlay == 7:
                        cm.append((unwatchedMenu, 'RunPlugin(%s?action=episodePlaycount&imdb=%s&tmdb=%s&season=%s&episode=%s&query=6&meta=%s)' % (sysaddon, imdb, tmdb, season, episode, sysmeta)))
                        meta.update({'playcount': 1, 'overlay': 7})
                    else:
                        cm.append((watchedMenu, 'RunPlugin(%s?action=episodePlaycount&imdb=%s&tmdb=%s&season=%s&episode=%s&query=7&meta=%s)' % (sysaddon, imdb, tmdb, season, episode, sysmeta)))
                        meta.update({'playcount': 0, 'overlay': 6})
                except:
                    meta.update({'playcount': 0, 'overlay': 6})

                if traktCredentials == True:
                    cm.append((traktManagerMenu, 'RunPlugin(%s?action=traktManager&name=%s&tmdb=%s&content=tvshow)' % (sysaddon, systvshowtitle, tmdb)))
                    # Only items from Trakt continue watching carry a playback id.
                    if i.get('playback_id'):
                        cm.append((control.lang(32649), 'RunPlugin(%s?action=traktPlaybackRemove&id=%s)' % (sysaddon, i['playback_id'])))

                cm.append((addToLibrary, 'RunPlugin(%s?action=tvshowToLibrary&tvshowtitle=%s&year=%s&imdb=%s&tmdb=%s)' % (sysaddon, systvshowtitle, year, imdb, tmdb)))

                if isFolder == False:
                    cm.append((playbackMenu, 'RunPlugin(%s?action=alterSources&url=%s&meta=%s)' % (sysaddon, sysurl, sysmeta)))
                    cm.append(('[I]Scrape Filterless[/I]', 'RunPlugin(%s?action=playUnfiltered&title=%s&year=%s&imdb=%s&tmdb=%s&season=%s&episode=%s&tvshowtitle=%s&premiered=%s&meta=%s&t=%s)' % (sysaddon, systitle, year, imdb, tmdb, season, episode, systvshowtitle, syspremiered, sysmeta, self.systime)))
                    cm.append(('[I]Custom Scrape[/I]', 'RunPlugin(%s?action=playCustom&title=%s&year=%s&imdb=%s&tmdb=%s&season=%s&episode=%s&tvshowtitle=%s&premiered=%s&meta=%s&t=%s)' % (sysaddon, systitle, year, imdb, tmdb, season, episode, systvshowtitle, syspremiered, sysmeta, self.systime)))
                    cm.append((clearProviders, 'RunPlugin(%s?action=clearCacheProviders)' % sysaddon))

                if kodiVersion < 17:
                    cm.append((infoMenu, 'Action(Info)'))

                thumb = meta.get('thumb', '') or fanart
                clearlogo = meta.get('clearlogo', '')
                clearart = meta.get('clearart', '')

                art = {'icon': thumb, 'thumb': thumb, 'fanart': fanart, 'banner': banner, 'poster': thumb, 'tvshow.poster': poster, 'season.poster': poster, 'landscape': landscape, 'clearlogo': clearlogo, 'clearart': clearart}

                try: item = control.item(label=label, offscreen=True)
                except: item = control.item(label=label)

                item.setArt(art)
                item.addContextMenuItems(cm)

                if isPlayable:
                    item.setProperty('IsPlayable', 'true')

                control.processListItem(item, meta)

                #control.addItem(handle=syshandle, url=url, listitem=item, isFolder=isFolder)
                list_items.append((url, item, isFolder))
            except:
                log_utils.log('ep_dir Exception', 1)
                pass

        # Next page, same as the movie and tv show lists. Only the Trakt
        # progress lists set 'next' (50 shows per page).
        try:
            url = items[0].get('next', '')
            if not url: raise Exception()
            nextMenu = control.lang(32053)
            if items[0].get('page'): nextMenu += '[I] (%s)[/I]' % str(int(items[0]['page']) + 1)
            icon = control.addonNext()
            url = '%s?action=calendar&url=%s' % (sysaddon, urllib_parse.quote_plus(url))
            try: item = control.item(label=nextMenu, offscreen=True)
            except: item = control.item(label=nextMenu)
            item.setArt({'icon': icon, 'thumb': icon, 'poster': icon, 'banner': icon, 'fanart': addonFanart})
            item.setProperty('SpecialSort', 'bottom')
            list_items.append((url, item, True))
        except:
            pass

        control.addItems(handle=syshandle, items=list_items, totalItems=len(list_items))
        control.content(syshandle, 'episodes')
        control.directory(syshandle, cacheToDisc=True)
        control.sleep(1000)
        views.setView('episodes', {'skin.estuary': 55, 'skin.confluence': 504})


    def addDirectory(self, items, queue=False):
        from sys import argv
        if not items:
            control.idle()
            if not trakt.hold_notice(): control.infoDialog('No content')
        else:
            # Lists of lists (the user's and liked Trakt lists): a saved one
            # is shown while Trakt holds reads off.
            trakt.hold_notice()

        sysaddon = argv[0]

        syshandle = int(argv[1])

        addonFanart, addonThumb, artPath = control.addonFanart(), control.addonThumb(), control.artPath()

        queueMenu = control.lang(32065)

        kodiVersion = control.getKodiVersion()

        list_items = []
        for i in items:
            try:
                name = i['name']

                plot = i.get('plot') or '[CR]'

                if i['image'].startswith('http'): thumb = i['image']
                elif not artPath == None: thumb = os.path.join(artPath, i['image'])
                else: thumb = addonThumb

                url = '%s?action=%s' % (sysaddon, i['action'])
                try: url += '&url=%s' % urllib_parse.quote_plus(i['url'])
                except: pass

                cm = []

                if queue == True:
                    cm.append((queueMenu, 'RunPlugin(%s?action=queueItem)' % sysaddon))

                try: item = control.item(label=name, offscreen=True)
                except: item = control.item(label=name)

                item.setArt({'icon': thumb, 'thumb': thumb, 'fanart': addonFanart})
                item.addContextMenuItems(cm)

                if kodiVersion > 19:
                    vtag = item.getVideoInfoTag()
                    vtag.setMediaType('video')
                    vtag.setPlot(plot)
                else:
                    item.setInfo(type='video', infoLabels={'plot': plot})

                #control.addItem(handle=syshandle, url=url, listitem=item, isFolder=True)
                list_items.append((url, item, True))
            except:
                pass

        control.addItems(handle=syshandle, items=list_items, totalItems=len(list_items))
        control.content(syshandle, '')
        control.directory(syshandle, cacheToDisc=True)

