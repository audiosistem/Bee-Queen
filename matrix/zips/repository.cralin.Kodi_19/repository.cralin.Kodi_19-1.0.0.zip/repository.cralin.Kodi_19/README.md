# cralin's repository for Kodi 19 (Matrix)

Repository containing cralin's addons for Kodi 19 (Matrix)

## Installation & Updates

* Download the latest released package from [here](https://github.com/cralin/repository.cralin.Kodi_19/releases/latest) and upload it to your Kodi installation.
* Go to ADD-ONS -> Install from zip file
* Browse for and select the uploaded zip file.


### Quick download links

Latest released package can be downloaded from [here](https://github.com/cralin/repository.cralin.Kodi_19/releases/latest).

