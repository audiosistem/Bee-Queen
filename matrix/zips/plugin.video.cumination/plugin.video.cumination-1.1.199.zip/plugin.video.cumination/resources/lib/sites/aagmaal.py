'''
    Cumination Site Plugin
    Copyright (C) 2020 Team Cumination

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import re
from resources.lib import utils
from resources.lib.adultsite import AdultSite

site = AdultSite('aagmaal', '[COLOR hotpink]Aag Maal[/COLOR]', 'https://aagmaal.bz/', 'aagmaal.png', 'aagmaal')


@site.register(default_mode=True)
def Main():
    site.add_dir('[COLOR hotpink]Categories[/COLOR]', site.url, 'Categories', site.img_cat)
    site.add_dir('[COLOR hotpink]OTT[/COLOR]', site.url + 'ott/', 'OTT', site.img_cat)
    site.add_dir('[COLOR hotpink]Search[/COLOR]', site.url + '?s=', 'Search', site.img_search)
    List(site.url)
    utils.eod()


@site.register()
def List(url):
    listhtml = utils.getHtml(url, site.url)
    match = re.compile(r'<article.+?src="([^"]+).+?href="([^"]+)">([^<]+)', re.DOTALL | re.IGNORECASE).findall(listhtml)
    for img, videopage, name in match:
        if '\n' in name:
            name = re.sub(r'\n\s*', ' ', name)
        name = utils.cleantext(name)
        site.add_download_link(name, videopage, 'Playvid', img, name)

    url = re.compile(r'class="vp-pagi-wrap".+?href="([^"]+)">Next', re.DOTALL | re.IGNORECASE).search(listhtml)
    if url:
        curr_pg = re.compile(r'class="vp-pagi-wrap".+?current">([^<]+)', re.DOTALL | re.IGNORECASE).search(listhtml)
        last_pg = re.compile(r'class="vp-pagi-wrap".+?hellip.+?href.+?>([^<]+)', re.DOTALL | re.IGNORECASE).search(listhtml)
        pgtxt = 'Currently in Page {0} of {1}'.format(curr_pg.group(1), last_pg.group(1))
        site.add_dir('[COLOR hotpink]Next Page...[/COLOR] ({0})'.format(pgtxt), url.group(1), 'List', site.img_next)
    utils.eod()


@site.register()
def ListOTT(url):
    listhtml = utils.getHtml(url, site.url)
    match = re.compile(r'<article[^>]+>\s*<a\s*href="([^"]+)[^>]+>\s*<img\s*src="([^"]+)"\s*alt="([^"]+)', re.DOTALL | re.IGNORECASE).findall(listhtml)
    for videopage, img, name in match:
        name = utils.cleantext(name)
        site.add_download_link(name, videopage, 'Playvid', img, name)

    purl = re.compile(r'class="next page-numbers"\s*href="([^"]+)').search(listhtml)
    if purl:
        curr_pg = re.compile(r'class="page-numbers\s*current">([^<]+)').search(listhtml)
        last_pg = re.compile(r'class="page-numbers"[^>]+>([^<]+)').findall(listhtml)[-1]
        pgtxt = 'Currently in Page {0} of {1}'.format(curr_pg.group(1), last_pg)
        site.add_dir('[COLOR hotpink]Next Page...[/COLOR] ({0})'.format(pgtxt), purl.group(1), 'ListOTT', site.img_next)
    utils.eod()


@site.register()
def Playvid(url, name, download=None):
    vp = utils.VideoPlayer(name, download)
    vp.progress.update(25, "[CR]Loading video page[CR]")
    videourl = ''

    videopage = utils.getHtml(url, site.url)
    pat1 = re.compile(r'''class="vp-dl-server">([^<]+)</div>\s*<p><a\s*class="vp-dl-btn"\s*href="([^"]+)''', re.DOTALL | re.IGNORECASE)
    pat2 = re.compile(r'''<br\s*/>\s*([\d]+)\.\s*<a\s*href="([^"]+)''', re.DOTALL | re.IGNORECASE)
    links = pat1.findall(videopage) or pat2.findall(videopage)
    if links:
        links = {host: link for host, link in links if vp.resolveurl.HostedMediaFile(link)}
        videourl = utils.selector('Select link', links)
    else:
        r = re.search(r'<iframe\s*(?:loading="lazy"\s*)?src="([^"]+)', videopage)
        if r:
            videourl = r.group(1)
    if not videourl:
        r = re.search(r'<article.+?iframe\s*data-src="([^"]+)', videopage, re.DOTALL | re.IGNORECASE)
        if r:
            videourl = r.group(1)

    if not videourl:
        utils.notify('Oh Oh', 'No Videos found')
        vp.progress.close()
        return

    vp.play_from_link_to_resolve(videourl)


@site.register()
def Categories(url):
    cathtml = utils.getHtml(url, site.url)
    cats = re.compile(r'title">Categories</h3>(.+?)</div>', re.DOTALL | re.IGNORECASE).search(cathtml)
    if cats:
        match = re.compile(r'<li><a\s*href="([^"]+)">([^<]+)', re.DOTALL | re.IGNORECASE).findall(cats.group(1))
        for catpage, name in match:
            name = utils.cleantext(name)
            site.add_dir(name, catpage, 'List')
        utils.eod()


@site.register()
def OTT(url):
    otthtml = utils.getHtml(url, site.url)
    otts = re.compile(
        r'class="vp-tax-index-card__thumb"\s*href="([^"]+)[^>]+><img\s*src="([^"]+)"\s*alt="([^"]+).+?(\d+)</span>',
        re.DOTALL | re.IGNORECASE
    ).findall(otthtml)
    if otts:
        for catpage, thumb, name, vids in otts:
            name = '{0} [COLOR cyan][I][{1} video(s)][/I][/COLOR]'.format(name, vids)
            site.add_dir(name, catpage, 'ListOTT', thumb)

        purl = re.compile(r'class="next page-numbers"\s*href="([^"]+)').search(otthtml)
        if purl:
            curr_pg = re.compile(r'class="page-numbers\s*current">([^<]+)').search(otthtml)
            last_pg = re.compile(r'class="page-numbers"[^>]+>([^<]+)').findall(otthtml)[-1]
            pgtxt = 'Currently in Page {0} of {1}'.format(curr_pg.group(1), last_pg)
            site.add_dir('[COLOR hotpink]Next Page...[/COLOR] ({0})'.format(pgtxt), purl.group(1), 'OTT', site.img_next)

        utils.eod()


@site.register()
def Search(url, keyword=None):
    searchUrl = url
    if not keyword:
        site.search_dir(url, 'Search')
    else:
        title = keyword.replace(' ', '+')
        searchUrl = searchUrl + title
        List(searchUrl)
