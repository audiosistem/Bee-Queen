# Change Log

Brief descriptions of changes will be logged here. Note that unless otherwise specified, all future versions should be backwards compatible with older versions.

## [1.6.8] - 2017-12-21
- Remove support for EOL Python 3.3

## [1.6.7] - 2017-03-22
- Make SocksiPy legacy functions kwarg-compatible. See issue [#71](https://github.com/Anorov/PySocks/pull/71).
- Use setuptools in setup.py to support wheel. See issue [#73](https://github.com/Anorov/PySocks/pull/73).
- Test and logging enhancements

## [1.6.6] - 2017-01-29
- Full test suite finally added
- Travis CI enabled for project
