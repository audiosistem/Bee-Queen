# Kodi-plugin.video.playlistal8ina
Taking ownership of plugin.video.playlistal8ina previously owned by Avigdork
See: https://github.com/avigdork/xbmc-avigdork/pull/8#issuecomment-416955692
